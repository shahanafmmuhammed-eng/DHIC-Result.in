/* DHICResultApp.jsx - main app component (tailwind expected) */
import React, { useEffect, useState, useMemo } from "react";
import { motion } from "framer-motion";

export default function DHICResultApp() {
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [query, setQuery] = useState("");
  const [filterStatus, setFilterStatus] = useState("ALL");
  const [sortBy, setSortBy] = useState("total");
  const [sortDir, setSortDir] = useState("desc");

  useEffect(() => {
    fetch("./results.json")
      .then((r) => { if (!r.ok) throw new Error("Failed to load results.json: " + r.status); return r.json(); })
      .then((data) => { setResults(data); setLoading(false); })
      .catch((err) => { setError(err.message); setLoading(false); });
  }, []);

  const filtered = useMemo(() => {
    let out = results;
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      out = out.filter((r) => r.reg_no.toLowerCase().includes(q) || r.name.toLowerCase().includes(q));
    }
    if (filterStatus === "PASS") out = out.filter((r) => r.status === "PASS");
    if (filterStatus === "FAIL") out = out.filter((r) => r.status === "FAIL");
    const dir = sortDir === "asc" ? 1 : -1;
    out = [...out].sort((a, b) => {
      if (sortBy === "total") return (a.total - b.total) * dir;
      if (sortBy === "rank") return (a.rank - b.rank || a.total - b.total) * dir;
      if (sortBy === "reg_no") return a.reg_no.localeCompare(b.reg_no) * dir;
      if (sortBy === "name") return a.name.localeCompare(b.name) * dir;
      return 0;
    });
    return out;
  }, [results, query, filterStatus, sortBy, sortDir]);

  function exportCsv(rows) {
    const header = ["reg_no","name","hadees","fiqh","insha","quran_hifz","azkar","total","status","rank"];
    const lines = [header.join(",")];
    for (const r of rows) {
      lines.push([r.reg_no, `"${r.name.replace(/"/g, '""')}"`, r.hadees, r.fiqh, r.insha, r.quran_hifz, r.azkar, r.total, r.status, r.rank===null?"":r.rank].join(","));
    }
    const blob = new Blob([lines.join("\n")], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a"); a.href = url; a.download = "dhic_results_export.csv"; a.click(); URL.revokeObjectURL(url);
  }

  function ResultCard({ student }) {
    if (!student) return null;
    return (
      <div className="p-4 border rounded-lg shadow-sm bg-white">
        <div className="flex items-center justify-between">
          <div><div className="text-sm text-neutral-500">Register No</div><div className="font-medium">{student.reg_no}</div></div>
          <div className="text-right"><div className="text-sm text-neutral-500">Status</div><div className={`font-semibold ${student.status === "PASS" ? "text-green-600" : "text-red-600"}`}>{student.status}</div></div>
        </div>
        <h3 className="mt-4 text-lg font-semibold">{student.name}</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
          <div className="p-2 border rounded"><div className="text-xs text-neutral-500">Hadees</div><div className="text-sm font-medium">{student.hadees}</div></div>
          <div className="p-2 border rounded"><div className="text-xs text-neutral-500">Fiqh</div><div className="text-sm font-medium">{student.fiqh}</div></div>
          <div className="p-2 border rounded"><div className="text-xs text-neutral-500">Insha</div><div className="text-sm font-medium">{student.insha}</div></div>
          <div className="p-2 border rounded"><div className="text-xs text-neutral-500">Quran & Hifz</div><div className="text-sm font-medium">{student.quran_hifz}</div></div>
          <div className="p-2 border rounded"><div className="text-xs text-neutral-500">Azkar</div><div className="text-sm font-medium">{student.azkar}</div></div>
          <div className="p-2 border rounded"><div className="text-xs text-neutral-500">Total</div><div className="text-sm font-medium">{student.total}</div></div>
          <div className="p-2 border rounded"><div className="text-xs text-neutral-500">Rank</div><div className="text-sm font-medium">{student.rank}</div></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6 bg-gray-50">
      <div className="max-w-6xl mx-auto">
        <header className="mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div><h1 className="text-2xl font-bold">DHIC Result Portal</h1><p className="text-sm text-neutral-600">Search results by Register Number or Name</p></div>
          <div className="w-full md:w-96">
            <div className="flex gap-2">
              <input value={query} onChange={(e)=>setQuery(e.target.value)} placeholder="Search by reg no or name" className="flex-1 px-3 py-2 border rounded"/>
              <button onClick={()=>{ const found = results.find((r)=> r.reg_no === query || r.reg_no === query.trim()); if(found) setQuery(found.reg_no); }} className="px-3 py-2 bg-blue-600 text-white rounded">Find</button>
            </div>
            <div className="mt-2 flex gap-2">
              <select value={filterStatus} onChange={(e)=>setFilterStatus(e.target.value)} className="px-2 py-1 border rounded"><option value="ALL">All</option><option value="PASS">Pass</option><option value="FAIL">Fail</option></select>
              <select value={sortBy} onChange={(e)=>setSortBy(e.target.value)} className="px-2 py-1 border rounded"><option value="total">Sort by Total</option><option value="rank">Sort by Rank</option><option value="reg_no">Sort by Reg No</option><option value="name">Sort by Name</option></select>
              <button onClick={()=>setSortDir(d=>d==="asc"?"desc":"asc")} className="px-2 py-1 border rounded">{sortDir==="asc"?"Asc":"Desc"}</button>
              <button onClick={()=>exportCsv(filtered)} className="ml-auto px-3 py-1 border rounded bg-white">Export CSV</button>
            </div>
          </div>
        </header>

        <main className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <section className="md:col-span-1">
            <div className="p-3 bg-white border rounded">
              <h2 className="font-semibold mb-2">Quick Result</h2>
              {loading ? <div>Loading results...</div> : error ? <div className="text-red-600">{error}</div> : <ResultCard student={results.find((r)=> r.reg_no === query.trim()) || null} />}
              <div className="mt-3 text-xs text-neutral-600">Tip: type full register number (e.g. 1002) and press Find to show the detailed card.</div>
            </div>

            <div className="mt-4 p-3 bg-white border rounded">
              <h3 className="font-medium">Stats</h3>
              <div className="mt-2 text-sm">
                <div>Total students: {results.length}</div>
                <div>Showing: {filtered.length}</div>
                <div>Pass: {results.filter((r)=> r.status==="PASS").length}</div>
                <div>Fail: {results.filter((r)=> r.status==="FAIL").length}</div>
              </div>
            </div>
          </section>

          <section className="md:col-span-2">
            <div className="p-3 bg-white border rounded overflow-auto">
              <h2 className="font-semibold mb-3">Result Table</h2>
              <table className="min-w-full text-sm">
                <thead><tr className="text-left"><th className="p-2">Reg No</th><th className="p-2">Name</th><th className="p-2">Hadees</th><th className="p-2">Fiqh</th><th className="p-2">Insha</th><th className="p-2">Quran&Hifz</th><th className="p-2">Azkar</th><th className="p-2">Total</th><th className="p-2">Status</th><th className="p-2">Rank</th></tr></thead>
                <tbody>{filtered.map(s=> (<tr key={s.reg_no} className="border-t hover:bg-gray-50"><td className="p-2">{s.reg_no}</td><td className="p-2">{s.name}</td><td className="p-2">{s.hadees}</td><td className="p-2">{s.fiqh}</td><td className="p-2">{s.insha}</td><td className="p-2">{s.quran_hifz}</td><td className="p-2">{s.azkar}</td><td className="p-2">{s.total}</td><td className="p-2">{s.status}</td><td className="p-2">{s.rank}</td></tr>))}</tbody>
              </table>
            </div>
          </section>
        </main>

        <footer className="mt-6 text-xs text-neutral-500">Built for DHIC result publishing • Place <code>results.json</code> in the public folder.</footer>
      </div>
    </div>
  );
}