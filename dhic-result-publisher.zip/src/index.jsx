import React from 'react';
import ReactDOM from 'react-dom/client';
import DHICResultApp from './DHICResultApp';
import './index.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<DHICResultApp />);
