# DHIC Result Publisher
Static React app to publish student results (searchable) built for Darul Hikam Islamic Complex (DHIC).

What's included
- public/results.json - dataset (generated from your Excel)
- src/DHICResultApp.jsx - main app component
- src/index.jsx - app entry
- package.json - minimal dependencies
- .github/workflows/gh-pages.yml - optional GitHub Pages deploy workflow

How to use
1. Create a React app (Vite or CRA).
2. Copy src/DHICResultApp.jsx and src/index.jsx.
3. Place results.json into the public/ folder.
4. Install dependencies: npm install
5. Build and deploy or use GitHub Pages.

Notes
This app expects Tailwind CSS for styling (optional). You can also use plain CSS.
